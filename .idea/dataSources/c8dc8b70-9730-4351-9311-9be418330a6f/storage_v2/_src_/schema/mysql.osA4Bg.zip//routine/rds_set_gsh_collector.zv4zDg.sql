create
    definer = rdsadmin@localhost procedure rds_set_gsh_collector(IN p_period int)
begin
   declare v_es varchar(3);
   DECLARE sql_logging BOOLEAN;
   select @@sql_log_bin into sql_logging;
   set @@sql_log_bin=off;
   select variable_value into v_es from information_schema.global_variables where variable_name = 'EVENT_SCHEDULER';
   if v_es = 'ON' then
   	   alter event ev_rds_gsh_collector ON SCHEDULE EVERY p_period MINUTE STARTS CURRENT_TIMESTAMP ENABLE;
   	   select concat('Collector Enabled every ', p_period ,' Minutes, Scheduler is Active') as `Success`;
   else
   	   select 'Scheduler is NOT Active' as `Failure`
   	    union all
   	   select 'Please change the parameter event_scheduler=ON in your Parameter Group' as `Status`;
   end if;
   set @@sql_log_bin=sql_logging;
 end;

